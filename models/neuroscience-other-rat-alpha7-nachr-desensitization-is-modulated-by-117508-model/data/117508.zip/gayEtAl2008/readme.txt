These are the Delphi source files for the paper:

Gay EA, Giniatullin R, Skorinkin A, Yakel JL. Aromatic residues at
position 55 of rat alpha7 nicotinic acetylcholine receptors are
critical for maintaining rapid desensitization.  

J Physiol. 2008 Feb 15;586(4):1105-15. Epub 2007 Dec 20.
PMID: 18096596

These files were supplied by Dr Andrey Skorinkin.
