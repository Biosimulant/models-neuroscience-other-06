addpath ./util/
addpath ./model/
addpath ./plots/
addpath ./stimuli/
addpath ./params/
