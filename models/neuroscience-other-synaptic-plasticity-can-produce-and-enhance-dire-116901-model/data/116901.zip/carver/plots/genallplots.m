function genallplots
% GENALLPLOTS plots panels for figure 2
% CALLING SYNTAX: genallplots
% Code written by SEAN CARVER, last modified 12-5-2007
figure(1)
sine_grating('Response to Sine-Grating without Slow Depression',5,'s',1)
figure(2)
sine_grating('Response to Sine-Grating with Slow Depression',21)
