Please see the "User Manual.pdf" for an introduction to this
Spiking Neuron Basal Ganglia Model.
