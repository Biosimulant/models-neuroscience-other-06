These are the settings for fig. 10 of paper Diwakar et al, 2009.

Files are named as follows:
mf - mossy fiber
0p1 - probability of release of excitatory fibers: 0.1
0p3 - probability of release of excitatory fibers: 0.3
0p8 - probability of release of excitatory fibers: 0.8
_300 -indicating 300Hz


