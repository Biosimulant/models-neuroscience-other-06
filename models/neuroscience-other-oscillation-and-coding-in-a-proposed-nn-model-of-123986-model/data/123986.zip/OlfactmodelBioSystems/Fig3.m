%BioSystems 89(2007) 244-256
%G.Horcholle-Bossavit et al.
%Fig.3

global matcan indican

Fabrican(2,5,5,15)

figure
NED=Evolumatcan(matcan,indican);
hold on
disp('1')
Fabrican(2,5,5,21)
NED=Evolumatcan(matcan,indican);
disp('2')
Fabrican(2,5,5,51)
NED=Evolumatcan(matcan,indican);
disp('3')
Fabrican(2,5,5,101)
NED=Evolumatcan(matcan,indican);
disp('4')
set(gcf,'color',[1 1 1]);