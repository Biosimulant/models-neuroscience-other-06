%BioSystems 89(2007) 244-256
%G.Horcholle-Bossavit et al.
%Fig.4

global g
Litpar('par21h35_4_12')
Litsim('sim21h35_4_12')
g=1;
for i=[2060 4591]
    Simulnum(i)
    g=g+1;
end
