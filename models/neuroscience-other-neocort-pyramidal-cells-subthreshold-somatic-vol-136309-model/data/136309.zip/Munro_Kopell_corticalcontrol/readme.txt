These folders contain all of the code necessary to generate the data
for Munro & Kopell 2012. All of the code for the axon models in NEURON
is contained in the NEURON folder. The MATLAB folder contains all code
for the neocortical network model, to analyze the antidromic geometric
ratios in the 3D reconstructions, and compiled data outputed from
NEURON used for this code. Please see the readme.txt files in those
folders for a description of the individual files.
