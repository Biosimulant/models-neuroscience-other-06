This is the readme for the models associated with the paper:

Pilly PK, Grossberg S (2013) Spiking neurons in a hierarchical
self-organizing map model can learn to develop spatial and temporal
properties of entorhinal grid cells and hippocampal place cells PLOS
One 8(4):e60599

This is the matlab code that was used by the paper authors.
