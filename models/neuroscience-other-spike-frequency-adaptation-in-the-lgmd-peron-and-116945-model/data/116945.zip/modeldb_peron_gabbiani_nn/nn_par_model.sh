screen -d -m /Applications/MATLAB_R2007b/bin/matlab  -nojvm -nosplash -r "daemon('nn_par_mat/')"

