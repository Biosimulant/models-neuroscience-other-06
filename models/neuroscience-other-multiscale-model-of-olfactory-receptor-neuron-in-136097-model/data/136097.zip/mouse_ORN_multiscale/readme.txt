This is the readme for the model associated with the AChems abstract:

Dougherty DP (2009) Workshop: Computational Problems in Sequential
Stages of Odor Processing. Modeling Diversity in the Signal
Transduction of the Mouse Olfactory Receptor Neuron. Abstracts from
the Thirty-first Annual Meeting of the Association for Chemoreception
Sciences AChemS:A13-A13

This XPP code was supplied by Daniel Dougherty.  The first few lines
of the ode files contains information on the simulations.
