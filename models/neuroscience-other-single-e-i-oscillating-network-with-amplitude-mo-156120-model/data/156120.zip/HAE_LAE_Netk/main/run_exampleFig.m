path(path,'./../Matlab_support/spikeTrainAnalysis/')
run('.\output_matlab\WaxingWaning.m')
I_E_frh;
conv_alpha_ex;
fft_example;
wavlet_ex;
raster_envelSpline;
colorbar('delete')


