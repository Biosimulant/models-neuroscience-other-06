figure(1); print varsiiEt.ps; 
figure(2); print varsiiEth.ps; 
figure(3); print varsiiEM.ps; 
figure(4); print varsiiIt.ps; 
figure(5); print varsiiIth.ps; 
figure(6); print varsiiIM.ps;