function cc=kcoeff(a,n);
	
cc=exp(-a^2*n.^2)/pi; 


