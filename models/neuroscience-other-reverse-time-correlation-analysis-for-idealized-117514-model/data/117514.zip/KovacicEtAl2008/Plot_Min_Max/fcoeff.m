function fcc=fcoeff(sigma,n);
	
fcc=exp(-sigma^2*n.^2)/pi;



