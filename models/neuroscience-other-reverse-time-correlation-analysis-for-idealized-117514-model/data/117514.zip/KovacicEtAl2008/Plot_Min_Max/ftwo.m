function b=ftwo(gamma,lambda,T);

b=1./(gamma+lambda*T);