function out = rms(in);
out = sqrt(mean(in.^2));