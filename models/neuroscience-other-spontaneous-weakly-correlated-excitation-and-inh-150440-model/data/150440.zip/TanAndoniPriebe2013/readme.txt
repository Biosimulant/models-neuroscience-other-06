The Brian code for the paper:

Tan AY, Andoni S, Priebe NJ (2013) A spontaneous state of weakly
correlated synaptic excitation and inhibition in visual
cortex. Neuroscience 247:364-75

is supplied in this archive.  Brian is freely available from
http://briansimulator.org

After installing Brian run with a command like
python TanAndoniPriebe2013_BrianCode.py

Alternatively, the code can be easily run in Spyder, a user-friendly
interface for Python.

Spyder is freely available from http://code.google.com/p/spyderlib/

After installing Brian and Spyder run by opening the code in Spyder,
then press the F5 key.
