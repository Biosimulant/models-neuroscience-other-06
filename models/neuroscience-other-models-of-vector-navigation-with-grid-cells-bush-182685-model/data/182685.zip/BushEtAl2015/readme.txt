Please see the Readme.pdf for detailed instructions on how to run the model.
