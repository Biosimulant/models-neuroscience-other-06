This is the readme for the models associated with the paper:

Dangerfield CE, Kay D, Burrage K (2012) Modeling ion channel dynamics
through reflected stochastic differential equations Phys Rev E
85(5):051907

This is the matlab code that the paper authors used. Please see
additional help provided in the matlab files in the two sudirectories
in this archive (at the top of the files).
