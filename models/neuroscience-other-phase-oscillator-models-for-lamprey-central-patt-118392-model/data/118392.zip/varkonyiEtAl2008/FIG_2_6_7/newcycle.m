function [y a b]=newcycle(t,x)
a=1;
b=1;
y=x(3);
%y=FHNagumo(t,x);
%y=y(1);
