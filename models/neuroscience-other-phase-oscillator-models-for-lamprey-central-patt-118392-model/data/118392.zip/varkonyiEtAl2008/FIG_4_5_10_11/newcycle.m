function [y a b]=newcycle(t,x)
a=1;
b=1;
%y=-wilson(t,x);
y=x(1)-.25;
%y=y(1);