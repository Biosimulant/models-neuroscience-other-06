NQS is a databasing program with a query command modeled loosely on the SQL select command. 

Please see the manual NQS.pdf for details of use.

An NQS database must be populated with data to be used.  You may wish to download
MFP.zip (model fingerprint) which provides an example of NQS use. 
