#ifndef _IT_channel_H_
#define _It_channel_H_
void modelIT(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
