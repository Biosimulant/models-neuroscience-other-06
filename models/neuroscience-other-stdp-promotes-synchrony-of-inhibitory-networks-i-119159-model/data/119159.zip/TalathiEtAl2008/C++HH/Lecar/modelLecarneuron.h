#ifndef _modelLecarneuron_H_
#define _modelLecarneuron_H_

void modelLecarneuron(double t,double *x,double *dx,double *parameter,double *extra);
#endif
