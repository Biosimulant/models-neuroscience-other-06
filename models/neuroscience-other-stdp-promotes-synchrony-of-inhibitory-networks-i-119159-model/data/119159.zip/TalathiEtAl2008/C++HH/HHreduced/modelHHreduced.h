#ifndef _modelHHreduced_H_
#define _modelHHreduced_H_

void modelHHreduced(double t,double *x,double *dx,double *parameter,double *extra);
#endif
