#ifndef _IK12_channel_H_
#define _IK12_channel_H_
void modelIK12(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
