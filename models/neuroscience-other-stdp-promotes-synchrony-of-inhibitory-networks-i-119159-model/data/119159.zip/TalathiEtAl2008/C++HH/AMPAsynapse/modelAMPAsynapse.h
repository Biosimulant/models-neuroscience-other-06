#ifndef _AMPA_Synapse_H_
#define _AMPA_Synapse_H_
void modelAMPAsynapse(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
