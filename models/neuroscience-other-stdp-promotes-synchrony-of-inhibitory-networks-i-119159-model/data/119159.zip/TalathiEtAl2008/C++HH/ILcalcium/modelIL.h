#ifndef _IL_channel_H_
#define _It_channel_H_
void modelIL(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
