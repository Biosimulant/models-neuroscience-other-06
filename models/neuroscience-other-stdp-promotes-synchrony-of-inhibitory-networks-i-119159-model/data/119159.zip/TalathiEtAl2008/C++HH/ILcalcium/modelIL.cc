#include "modelIL.h"
#include "math.h"

void modelIL(double t,double *x,double *dx,double *parameter,double *extra)
{
double v;
double mco,tmco,hco,thco;
v=extra[1];
}

