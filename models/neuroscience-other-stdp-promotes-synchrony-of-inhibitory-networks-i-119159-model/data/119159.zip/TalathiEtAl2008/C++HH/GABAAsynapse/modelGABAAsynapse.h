#ifndef _GABAA_Synapse_H_
#define _GABAA_Synapse_H_
void modelGABAAsynapse(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
