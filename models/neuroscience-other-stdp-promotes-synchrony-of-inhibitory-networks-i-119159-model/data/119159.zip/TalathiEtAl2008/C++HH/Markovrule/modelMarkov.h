#ifndef _Markov_rule_H_
#define _Markov_rule_H_
void modelMarkov(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
