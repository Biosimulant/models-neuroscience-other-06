#ifndef _modelQuadraticNeuron_H_
#define _modelQuadraticNeuron_H_

void modelQuadraticNeuron(double t,double *x,double *dx,double *parameter,double *extra);
#endif
