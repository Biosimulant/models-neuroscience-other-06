#ifndef _modelLorenz_H_
#define _modelLorenz_H_

void modelLorenz(double t,double *x,double *dx,double *parameter,double *extra);

#endif
