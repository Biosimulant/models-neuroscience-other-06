#ifndef _IAHP_channel_H_
#define _It_channel_H_
void modelIAHP(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
