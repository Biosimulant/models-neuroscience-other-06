IonChannelLab is available at: 
http://www.jadesantiago.com/Electrophysiology/IonChannelLab/Download/
For more information on the program see De Santiago Castillo et al. Channels (2010).

The .ichl files contain the schemes, parameters and simulations used.  The interface 
contains two areas:
1)Kinetic modeling - schemes and parameters
2)Simulations - where experiments are run

There may be some need to change sampling intervals or number of sweeps in the double 
pulse protocols to get the full resolution.  Simulations may be saved as a .txt file 
by clicking the save button and selecting simulation.  To recreate figure 2, there will 
be a need to save each SSI and current family before switching the lambda1 (kio) value 
and repeating.


Any questions can be directed to david.ritter@jefferson.edu