#!/bin/sh

./main 3 o w.0 w.1 33
./xcorr o.a o.a c
