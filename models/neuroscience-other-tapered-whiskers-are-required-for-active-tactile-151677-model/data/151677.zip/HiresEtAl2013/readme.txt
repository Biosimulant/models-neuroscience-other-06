This is the model associated with the paper:

Hires SA, Pammer L, Svoboda K, Golomb D (2013) Tapered whiskers are
required for active tactile sensation. Elife 2:e01350

This is the code that the authors used.  Please contact David Golomb
for more information.
