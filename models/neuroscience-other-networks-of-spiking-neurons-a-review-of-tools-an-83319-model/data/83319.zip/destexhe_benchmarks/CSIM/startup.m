LSMROOT='../../../lsm';  % set LSMROOT to the root directory

addpath(LSMROOT);
lsm_startup;
