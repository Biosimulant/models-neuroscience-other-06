This is the readme for the code associated with the paper:

Electrogenic properties of the Na+/K+ ATPase controls transitions
between normal and pathological brain states Giri P Krishnan, Gregory
Filatov, Andrey Shilnikov, Maxim Bazhenov January 14, 2015

DOI: 10.1152/jn.00460.2014

This code was supplied by Giri Prashanth Krishnan and runs with the
CONTENT package.

