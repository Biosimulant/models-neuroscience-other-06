These matlab files are an example of how to transform the segmented neurites from www.neuromorpho.org and generate the input file for Neurite.

The bash file is to create the video of the simulation (this option is only available for structures without branching). To this end, you need to execute your simulation with the "g" parameter. This file must be executed from the same folder where the GUI_captures folder is.
