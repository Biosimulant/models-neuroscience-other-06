//
//
// File author(s):  <Julian Andres Garcia Grajales>, (C) 2014
//
// Copyright: this software is licenced under the terms stipulated in the license.txt file located in its root directory
//
//

#ifndef _input_H_
#define _input_H_

#include "neurite.h"

extern void inputArgs(int argc, char **argv, char *args, input &in);
#endif
