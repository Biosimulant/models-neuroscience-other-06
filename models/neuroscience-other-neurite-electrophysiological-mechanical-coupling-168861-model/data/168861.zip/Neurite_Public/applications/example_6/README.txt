This is the example 6. It is a passive tree created synthetically with several branching points. In the output folder, in the *.dat file, you have the potential vs time at a given point along the tree.

./example_6.sh processor solver example_6

with processor = cpu or gpu, and solver = E or I.
