This is the example 3. It is a myelinated axon with one branching point. In the *.dat file you have the potential vs time at a given point along the axon.

./example_3.sh processor solver example_3

with processor = cpu or gpu, and solver = E or I.
