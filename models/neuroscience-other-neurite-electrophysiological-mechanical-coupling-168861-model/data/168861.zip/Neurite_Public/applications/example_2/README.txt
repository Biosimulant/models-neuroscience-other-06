This is the example 2. It is a myelinated axon. In the output folder, in the *.dat file, you have the potential vs time at a given point along the axon.

./example_2.sh processor solver example_2

with processor = cpu or gpu, and solver = E or I.
