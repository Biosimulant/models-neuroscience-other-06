This is the example 5. It is a passive cable with one branching point. In the output folder, in the *.dat file, you have the potential vs time at a given point along the cable

./example_5.sh processor solver example_5

with processor = cpu or gpu, and solver = E or I.
