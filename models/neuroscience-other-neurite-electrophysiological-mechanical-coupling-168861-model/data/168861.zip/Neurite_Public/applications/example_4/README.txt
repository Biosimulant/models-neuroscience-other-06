This is the example 4. It is a passive cable. In the output folder, in the *.dat file, you have the potential vs time at a given point along the cable.

./example_4.sh processor solver example_4

with processor = cpu or gpu, and solver = E or I.
