This is the example number 9. It is a long myelinated axon with the aim of testing the parallel implementation of Neurite. The sequential simulation needs days to finish the simulation, whereas the parallel version takes minutes. In the output folder, in the *.dat file, you have the potential vs time at a given point along the axon.

Example:

./example_9.sh cpu E example_9
