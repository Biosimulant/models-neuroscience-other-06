This is the simulation for one Hodgkin-Huxley element. In the output folder, in the *.dat file, you have the potential vs time

./example_1.sh processor solver example_1

with processor = cpu or gpu, and solver = E or I.
