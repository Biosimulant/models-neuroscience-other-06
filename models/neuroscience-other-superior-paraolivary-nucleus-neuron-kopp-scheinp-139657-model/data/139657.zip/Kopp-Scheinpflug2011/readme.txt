Changelog
=========

* 20220924: Update MOD files to avoid declaring variables and functions with the same name.
  See https://github.com/neuronsimulator/nrn/pull/1992
