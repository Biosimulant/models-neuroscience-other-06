function R0 = getRHS( P, El, gl )

R0 = El.*(P*gl);

