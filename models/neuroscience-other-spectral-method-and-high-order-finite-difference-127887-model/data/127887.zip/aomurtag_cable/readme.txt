This is the readme for the models associated with the paper

Omurtag A, Lytton WW (2010) Spectral method and high-order finite
differences for the nonlinear cable equation. Neural Comput 22:2113-36

This is the matlab code the authors used.  Please contact Ahmet Omurtag for help:
aomurtag at gmail.com

There is help at the top of the matlab files in the mfiles folder.
