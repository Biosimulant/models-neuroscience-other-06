This is the readme for the model code for the paper:

Cannon RC, O`Donnell C, Nolan MF (2010) Stochastic ion channel gating
in dendritic neurons: morphology dependence and probabilistic synaptic
activation of dendritic spikes. PLoS Comput Biol

These model files were contributed by Matt Nolan and Cian O'Donnell.

The code for figures 2, 5, 6&7, 8&9 are supplied in the fig2, fig5,
figs6and7, and figs8and9 folders.
