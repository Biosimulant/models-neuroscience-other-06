execfile('init.py')
execfile('unpickleAll.py')
execfile('analyze.py')
